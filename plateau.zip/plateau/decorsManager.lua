local camera = require("cameraManager")

local decorsManager = {}
decorsManager.liste_decors = {}
liste_horizontal = {0,0,4,0,4,1,0,1}
liste_vertical   = {0,0,1,0,1,4,0,4}
liste_slopeNeg   = {0,1,1,0,4,3,3,4}
liste_slopePos   = {0,3,3,0,4,1,1,4}
liste_LettreG = {0,1 ,1,0 ,3,0 ,4,1 ,4,2 ,3,2 ,2,1 ,1,2 ,1,4 ,2,5 ,3,5 ,3,4 ,2,4 ,2,3 ,4,3 ,4,5 ,3,6 ,1,6 ,0,5}
liste_slopeNeg2   = {0,0,2,0,3,2,2,2,2,1,0,1,0,2,-1,2}


decorsManager.CreerDecors = function (pType, pShape, pX, pY, pScale)
local decors = {}
local liste_shape = {}
local n

decors.type = pType
decors.shape = pShape
decors.x = pX
decors.y = pY
decors.scale = pScale
decors.points= {}

if decors.shape == "Horizontal"    then liste_shape = liste_horizontal end
if decors.shape == "Vertical"      then liste_shape = liste_vertical   end
if decors.shape == "PentePositive" then liste_shape = liste_slopePos   end
if decors.shape == "PenteNegative" then liste_shape = liste_slopeNeg   end

----- fonction pour crééer les coordonnées des points du polygone selon sa pShape, son origine (pX,pY) et sa pScale (en pixels)
for n = 1, #liste_shape, 1 do
  local res = liste_shape[n]
  if n%2 == 0 then -----si n est pair ON TRAITE LES Y des sommets du polygone
    res = pY + (res * pScale)
  elseif n%2 ==1 then ------------si n est impair, ON TRAITE LES X des sommets du polygone
    res = pX + (res * pScale)
  end
  table.insert(decors.points, res)  
end
--


table.insert(decorsManager.liste_decors, decors)



return decors

end
--


decorsManager.draw = function()
  local n
  for n=1, #decorsManager.liste_decors, 1 do 
    local decors = decorsManager.liste_decors[n]
    love.graphics.setColor(255,25,25)
    love.graphics.polygon("fill", decors.points)
    love.graphics.setColor(255,255,255)
  end
  --
  if phase == "placerDecors" then
    love.graphics.setColor(colorLightGrey)
    love.graphics.rectangle("fill", camera.CalcX(100), camera.CalcY(100), (200*camera.scaleX), (400*camera.scaleY))
    love.graphics.setColor(colorBlack)
    love.graphics.setFont(infoFont)
    love.graphics.print("Selectionner decors", camera.CalcX(130), camera.CalcY(105), 0, camera.scaleX, camera.scaleY)
    love.graphics.print("Selectionner decors", camera.CalcX(130), camera.CalcY(105), 0, camera.scaleX, camera.scaleY)
    love.graphics.print("Type de decors :", camera.CalcX(105), camera.CalcY(125), 0, camera.scaleX, camera.scaleY)
    love.graphics.setColor(colorBlue)
    love.graphics.rectangle("fill", camera.CalcX(115), camera.CalcY(148), (camera.scaleX * 45), (camera.scaleY * 22))
    love.graphics.setColor(colorBlack)
    love.graphics.print("Haut", camera.CalcX(120), camera.CalcY(150), 0, camera.scaleX, camera.scaleY)
    love.graphics.setColor(colorGreen)
    love.graphics.rectangle("fill", camera.CalcX(170), camera.CalcY(148), (camera.scaleX * 35), (camera.scaleY * 22))
    love.graphics.setColor(colorBlack)
    love.graphics.print("Bas", camera.CalcX(175), camera.CalcY(150), 0, camera.scaleX, camera.scaleY)
    love.graphics.rectangle("fill", camera.CalcX(219), camera.CalcY(152), (camera.scaleX * 70), (camera.scaleY * 22))
    love.graphics.setColor(colorRed)
    love.graphics.rectangle("fill", camera.CalcX(215), camera.CalcY(148), (camera.scaleX * 70), (camera.scaleY * 22))
    love.graphics.setColor(colorBlack)
    love.graphics.print("Infranch.", camera.CalcX(218), camera.CalcY(150), 0, camera.scaleX, camera.scaleY)
    
    love.graphics.setColor(colorWhite) 
  end
end
--
decorsManager.update = function(dt)
  
end
--


return decorsManager