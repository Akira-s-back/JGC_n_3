-- cette ligne permet d afficher des traces ds la console pdt l'execution du code
io.stdout:setvbuf('no')

-- Empeche love2d d antialiaser
love.graphics.setDefaultFilter("nearest")

-- Permet de DEBOGUER pas a pas ds ZeroBrane
if arg[#arg] == "-debug" then require("mobdebug").start() end
----------------------------------------------------------------------------


----------------------------------------------------------------------------
------------REQUIREs
local camera = require("cameraManager")
local decorsmanager= require("decorsManager")

------------Images et Sons
imgTerrain = love.graphics.newImage("Images/terrain_2048_1536_grid.png")
imgHeros = love.graphics.newImage("Images/carre_vert.png")
imgVierge = love.graphics.newImage("Images/ecran_vierge_1280_720.jpg")


------------couleurs et fonts
colorBlack = {0,0,0}
colorWhite = {255,255,255}
colorRed = {255, 25, 25}
colorGreen = {25, 255, 25}
colorBlue = {105,105,255, 255}
colorLightGrey = {200, 200, 200}
normalFont = love.graphics.newFont(20)
infoFont = love.graphics.newFont(15)
smallFont = love.graphics.newFont(10)
bigFont = love.graphics.newFont(50)



function love.load()
  love.window.setMode(1280,720)
  love.mouse.setGrabbed(true)
  dTest = 25
  ------------Ecran
  lgEcran , htEcran = love.window.getMode()
  
  ------------Terrain
  lgTerrain = imgTerrain:getWidth()
  htTerrain = imgTerrain:getHeight()
  osTerrainX = - lgTerrain/2
  osTerrainY = - htTerrain/2
  
  ------------Scene (le terrain etant le plateau, et la scene, la chambre dans laquelle on joue)
  lgScene = lgTerrain + lgEcran
  htScene = htTerrain + htEcran
  centreSceneX = lgScene / 2
  centreSceneY = htScene / 2
  origineTerrainX = 1024
  origineTerrainY = 768
  
------------Camera
  camera.x =0-(centreSceneX )
  camera.y =0-(centreSceneY )
  
  myCamScale = 5
  nMW  = 0
  listeScales = {}
  listeScales[1] = 3
  listeScales[2] = 2.5
  listeScales[3] = 2
  listeScales[4] = 1.5
  listeScales[5] = 1
  listeScales[6] = 1/2
  listeScales[7] = 1/3
  listeScales[8] = 1/4
  
  ------------Decors 
  decors1 = decorsmanager.CreerDecors("Haut", "Horizontal", 1150, 800, 30)
  decors2 = decorsmanager.CreerDecors("Haut", "PenteNegative", 1221, 1400, 42)
  
  
  ------------Autres
  mouseCtrl = false
  phase = ""
  
  print(centreSceneX -(lgEcran/2))
  print(centreSceneY -(htEcran/2))
  print(lgEcran)
  print(htEcran)
end
--
function love.update(dt)
  
  mX,mY = love.mouse.getPosition()
  xReel = camera.CalcX(mX)
  yReel = camera.CalcY(mY)
  
  ---------------------MVT A LA SOURIS ------------- TO DO REMPLACER AVEC UN CAMERA BOUNDS 
  
  ---------camera.x = -(origineTerrainX + lgTerrain) + (lgEcran/2) * camera.scaleX
  ---------Deplace la camera si la souris est a mins de 10 px des bords (quelquesoit le scale)
  ---------Permet de toujours positionner le x = valeur (ici -1024 et -3096) au milieu de l ecran (lgEcran/2)
  ---------Quelque soit le scale et le Dx
  ---------Ici, -1024/lgEcran et -3096(lgEcran+lgTerrain) correspondent aux coordonnes X du Terrain dans le referentiel de la camera
  --------- et -768/(htEcran) et -2304/(htEcran+htTerrain) au Y du Terrain 
  if mX < 10 then
    if camera.x < (((0.5 * lgEcran) * camera.scaleX) - origineTerrainX) then camera.MoveCam(dTest * 60 * dt * camera.scaleX, 0) end
    if camera.x >= (((0.5 * lgEcran) * camera.scaleX) + origineTerrainX) then camera.x = (((0.5 * lgEcran) * camera.scaleX) + origineTerrainX) end
  end
  --
  if mX > (lgEcran-10) then
    --print(" "..(- xReel + camera.scaleX * (lgEcran/2)))
    if camera.x > ((camera.scaleX * (lgEcran/2))- (origineTerrainX + lgTerrain)) then camera.MoveCam(-dTest * 60 * dt * camera.scaleX, 0) end
    if camera.x <= ((camera.scaleX * (lgEcran/2))- (origineTerrainX + lgTerrain)) then camera.x = ((camera.scaleX * (lgEcran/2))-(origineTerrainX + lgTerrain)) end
  end
  --
   if mY < 10 then
    if camera.y <= (((htEcran/2) * camera.scaleY) - origineTerrainY) then camera.MoveCam(0,dTest * 60 * dt * camera.scaleY) end
    if camera.y >(((htEcran/2) * camera.scaleY) - origineTerrainY) then camera.y = (((htEcran/2) * camera.scaleY) - origineTerrainY) end
  end
  --
  if mY > (htEcran-10) then
    --print(" "..(- xReel + camera.scaleX * (lgEcran/2)))
    if camera.y > ((camera.scaleY * (htEcran/2))- (origineTerrainY+htTerrain)) then camera.MoveCam(0, - dTest * 60 * dt * camera.scaleY) end
    if camera.y <= ((camera.scaleY * (htEcran/2))- (origineTerrainY+htTerrain)) then camera.y = ((camera.scaleY * (htEcran/2))-(origineTerrainY+htTerrain)) end
  end
  --
  ------ On definit un click alternatif via "ctrl-gauche"
  if love.keyboard.isDown("lctrl") then 
    mouseCtrl = true 
  else 
    mouseCtrl = false
  end
  --
end
--
function love.draw()
  camera.Set()
  -----------------------------------------------------
  
  love.graphics.draw(imgTerrain, centreSceneX -(lgEcran/2), centreSceneY - (htEcran/2))
  decorsmanager.draw()
  love.graphics.draw(imgHeros, 1100,800)
  love.graphics.setColor(colorBlue)
  --Permet d afficher toujours à (100,300) et (100,330) quelque soit : camera.x/y et camera.scaleX/Y
  if nMW <= -1 then love.graphics.setFont(bigFont) end
  if nMW >-1 and nMW <=1 then love.graphics.setFont(normalFont) end
  if nMW >1 then love.graphics.setFont(smallFont) end
  love.graphics.print("mX = "..mX.."  et  mY = "..mY, camera.CalcX(100), camera.CalcY(500))
  love.graphics.print("xReel = "..xReel.."  et  yReel = "..yReel, camera.CalcX(100), camera.CalcY(530))
  love.graphics.print("camX = "..camera.x.."  et  camY = "..camera.y, camera.CalcX(100), camera.CalcY(560))
  love.graphics.print("mouseCtrl = "..tostring(mouseCtrl), camera.CalcX(100), camera.CalcY(590))
  love.graphics.print("phase = "..phase, camera.CalcX(100), camera.CalcY(620))
  love.graphics.setColor(colorWhite)
  --
  -----------------------------------------------------
  camera.Unset()
  

end 
--
function love.keypressed(key)
  if key == "f10" then 
    love.mouse.setGrabbed(not love.mouse.isGrabbed())
  end
  --
  if key == "escape" then
    love.event.quit()
  end
  --
  if key == "d" then camera.MoveCam (-5*dTest * camera.scaleX, 0) end
  if key == "q" then camera.MoveCam(5*dTest * camera.scaleX, 0) end
  if key == "z" then camera.MoveCam(0, -dTest) end
  if key == "s" then camera.MoveCam(0, dTest) end
  if key == "a" then camera.RotateCam ( - (math.pi)/2 ) end
  if key == "e" then camera.RotateCam (  (math.pi)/2 ) end
  ----------------- TO DO
  ---------------- F... FullScreen, il faudrait probablement rajouter une fonction qui quand FulllScreen(true) 
  ---------------- remplacerait camera.scale par camera.scale*scaleFullScreen ! a voir
  if key == "f11" then love.window.setFullscreen(not love.window.getFullscreen()) end
  if key == "f1" and phase ~= "placerDecors" then 
    phase = "placerDecors" 
  elseif key == "f1" and phase == "placerDecors" then
    phase = ""
  end
print(key)
end
--
function love.wheelmoved(pDx, pDy)
  if mouseCtrl == false then
    nMW = nMW + pDy
    if nMW >=3 then nMW = 3 end
    if nMW <= -4 then nMW = -4 end
    myCamScale = 5 + nMW
    if myCamScale >= 8 then myCamScale = 8 end
    if myCamScale <= 1 then myCamScale = 1 end
    mZoomX, mZoomY = xReel, yReel
    print("nMW : "..nMW.."  myCamScale : "..myCamScale.." reelscale = "..listeScales[myCamScale])
    -----------Zoom et centre sur la souris
    camera.SetScale(listeScales[myCamScale], listeScales[myCamScale])
    camera.SetPosition(-mZoomX +(lgEcran/(2/listeScales[myCamScale])) , -mZoomY + (htEcran/(2/listeScales[myCamScale])) )
    -------------------
  end
  --
  
end
--
function love.mousepressed(x,y,button)
if button == 1 then  print("X : "..x.."   Y: "..y)  end
end
