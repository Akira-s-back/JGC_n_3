local particleManager = {}
local camera = require("cameraManager")

particleManager.liste_particles = {}

particleManager.CreerFumee = function (pType, pX, pY)
  local fumee = {}
  if pType == "fumee" then
    local n
    for n = 1 , 3 do
      particleManager.CreerParticle(pType, pX, pY, 0, -1, 10)
    end
    --
  end
  --  
end
--

particleManager.CreerParticle = function (pType, pX, pY,pVx, pVy, pLife)
  local particle = {}
  particle.type = pType
  particle.x = pX
  particle.y = pY
  particle.vx = pVx
  particle.vy = pVy
  particle.life = pLife
  particle.supprime = false
  
  table.insert(particleManager.liste_particles, particle)
  
  particle.Deplace = function (dt)
    particle.x = particle.x + (particle.vx * 60 * dt)
    particle.y = particle.y + (particle.vy * 60 * dt)
    particle.life = particle.life - 1
    if particle.life < 0 then particle.supprime = true end
  end
  --
  return particle
  
end
--

particleManager.update = function(dt)
  local n
  for n = #particleManager.liste_particles , 1, -1 do
    local p = particleManager.liste_particles[n]
    p.Deplace(dt)
    
    if p.supprime == true then table.remove(particleManager.liste_particles, n) end
    
  end
  --
  
end
--

particleManager.draw = function()
  local n
  for n = 1, #particleManager.liste_particles, 1 do
    p = particleManager.liste_particles[n]
    love.graphics.setColor(120 + math.random(-20,20), 120 + math.random(-20,20), 120 + math.random(-20,20))
    love.graphics.circle("fill", camera.CalcX(p.x), camera.CalcY(p.y),camera.scaleX * 3)
    
  end
  --
  
end
--



return particleManager