local camera = require("cameraManager")
local particlemanager = require("particleManager")
local decorsmanager = require("decorsManager")
-- Colors
colorBlack = {0,0,0}
colorWhite = {255,255,255}
colorRed = {255, 25, 25}
colorGreen = {25, 255, 25}
colorBlue = {105,105,255, 255}
colorLightGrey = {200, 200, 200}
colorClear = {255,255,255,0}
colorYellow = {255, 255, 0}

--Mouse Cursors
cursorArrow = love.mouse.getSystemCursor("arrow")
cursorHand = love.mouse.getSystemCursor("hand")
monCursor = false
-- Icones
icoHoriz = love.graphics.newImage("Images/icone_horiz.png")
icoHorizHov = love.graphics.newImage("Images/icone_horiz_hovered.png")
icoHorizSel = love.graphics.newImage("Images/icone_horiz_selected.png")
icoLettreL = love.graphics.newImage("Images/icone_lettreL.png")
icoLettreLHov = love.graphics.newImage("Images/icone_lettreL_hovered.png")
icoLettreLSel = love.graphics.newImage("Images/icone_lettreL_selected.png")
icoSlopeNeg = love.graphics.newImage("Images/icone_penteNeg.png")
icoSlopeNegHov = love.graphics.newImage("Images/icone_penteNeg_hovered.png")
icoSlopeNegSel = love.graphics.newImage("Images/icone_penteNeg_selected.png")
icoSlopePos = love.graphics.newImage("Images/icone_pentePos.png")
icoSlopePosHov = love.graphics.newImage("Images/icone_pentePos_hovered.png")
icoSlopePosSel = love.graphics.newImage("Images/icone_pentePos_selected.png")
icoVert  = love.graphics.newImage("Images/icone_vert.png")
icoVertHov  = love.graphics.newImage("Images/icone_vert_hovered.png")
icoVertSel  = love.graphics.newImage("Images/icone_vert_selected.png")
icoFlecheG = love.graphics.newImage("Images/ico_fleche_gauche.png")
icoFlecheGHov = love.graphics.newImage("Images/ico_fleche_gauche_hovered.png")
icoFlecheGClk = love.graphics.newImage("Images/ico_fleche_gauche_click.png")
icoFlecheD = love.graphics.newImage("Images/ico_fleche_droite.png")
icoFlecheDHov = love.graphics.newImage("Images/ico_fleche_droite_hovered.png")
icoFlecheDClk = love.graphics.newImage("Images/ico_fleche_droite_click.png")
icoPancarte = love.graphics.newImage("Images/pancarte.png")

local placeManager = {}
placeManager.decorsToPlace = {}
placeManager.decorsToPlace.taille = 20
placeManager.decorsToPlace.forme = "Horiz"
placeManager.decorsToPlace.type =  "Haut"
placeManager.decorsToPlace.liste_points = {}
placeManager.decorsToPlace.decors = {}
-------------
-- A FAIRE DEMAIN :
-- qd on place le decorToPlace : faire clignoter en rouge au milieu de l ecran , poser le decors avec clickG
-------------+
-- si j ai le temps, faire un "Nommer decors"
-- afficher liste des décors "f2"  --> supprimer decors / creer decors aleatoire

-------- Definitions des boxs/boutons de choix --  xMin, width, yMin, height, "Type", color

liste_boutons = {}
liste_boutons[1]  = {115, 45, 148, 22, "bt_type",   {"Haut", colorBlue}}
liste_boutons[2]  = {170, 35, 148, 22, "bt_type",   {"Bas", colorGreen}}
liste_boutons[3]  = {215, 70, 148, 22, "bt_type",   {"Infranch", colorRed}}
liste_boutons[4]  = {110, 50, 220, 50, "bt_forme",  {"Horiz", icoHoriz, icoHorizHov, icoHorizSel}}
liste_boutons[5]  = {170, 50, 220, 50, "bt_forme",  {"Lettre_L", icoLettreL, icoLettreLHov, icoLettreLSel}}
liste_boutons[6]  = {230, 50, 220, 50, "bt_forme",  {"vert.", icoVert, icoVertHov, icoVertSel}}
liste_boutons[7]  = {130, 50, 280, 50, "bt_forme",  {"Pente_Pos", icoSlopePos, icoSlopePosHov, icoSlopePosSel}}
liste_boutons[8]  = {210, 50, 280, 50, "bt_forme",  {"Pente_Neg", icoSlopeNeg, icoSlopeNegHov, icoSlopeNegSel}}
liste_boutons[9]  = {130, 30, 380, 30, "bt_fleche", {"Fleche_G", icoFlecheG, icoFlecheGHov, icoFlecheGClk}}
liste_boutons[10] = {240, 30, 380, 30, "bt_fleche", {"Fleche_D", icoFlecheD, icoFlecheDHov, icoFlecheDClk}}
liste_boutons[11] = {155, 90, 430, 60, "bt_ok",     {"Valider", icoPancarte, "Placer le décors a la souris"}}



placeManager.SetPlace = function()
  placeManager.monType = false
  placeManager.decorsToPlace.type =  "Haut"
  placeManager.decorsToPlace.color = colorRed
  placeManager.decorsToPlace.decors = {}
  monCursor = false
  monPlace = false
  
  --placeManager.decorsToPlace.liste_points = {}
end
--

placeManager.update = function(dt)
  if phase == "placerDecors" then
    if monCursor == true then love.mouse.setCursor(cursorHand) end
    placeManager.decorsToPlace.liste_points = decorsmanager.CalcSommets(placeManager.decorsToPlace.forme, xReel ,yReel, placeManager.decorsToPlace.taille)
    if monCursor == false then love.mouse.setCursor(cursorArrow) end   
    if not love.mouse.isDown(1) then monBool = true end
    local n
    ---------  VERIFIE SI ON SURVOLE UN DES BOUTONS
    for n = 1, #liste_boutons, 1 do 
      bouton = liste_boutons[n]
      if (mX > bouton[1]) and (mX < (bouton[1] + bouton[2])) and (mY > bouton[3]) and (mY < (bouton[3] + bouton[4])) then 
       --print(box)
        placeManager.monBouton = bouton  
        if placeManager.monBouton[5] == "bt_ok" then 
          love.mouse.setCursor(cursorHand) 
        else 
          love.mouse.setCursor(cursorArrow)
        end
        --
        ----------  Si ON CLICK SUR UN BOUTON
        if love.mouse.isDown(1)  then
          if placeManager.monBouton[5] == "bt_type" then
            placeManager.decorsToPlace.type = placeManager.monBouton[6][1]
            placeManager.decorsToPlace.color = placeManager.monBouton[6][2]
          elseif placeManager.monBouton[5] == "bt_forme" then
            placeManager.decorsToPlace.forme = placeManager.monBouton[6][1]
          elseif placeManager.monBouton[5] == "bt_ok" then
            monCursor = true
            monPlace = true
            monBool = false
          elseif placeManager.monBouton[5] == "bt_fleche" then
            if placeManager.monBouton[6][1] == "Fleche_G" then
              if monBool == true then
                placeManager.decorsToPlace.taille = placeManager.decorsToPlace.taille -5
              end
              monBool = false
              if placeManager.decorsToPlace.taille < 20 then placeManager.decorsToPlace.taille = 20 end
            elseif placeManager.monBouton[6][1] == "Fleche_D" then
              if monBool == true then
                placeManager.decorsToPlace.taille = placeManager.decorsToPlace.taille +5
              end
              monBool = false
              if placeManager.decorsToPlace.taille > 140 then placeManager.decorsToPlace.taille = 140 end
            end
            --           
          end
          --
        end 
        --
        return
      else 
        placeManager.monBouton = nil
        if monCursor == false then love.mouse.setCursor(cursorArrow) end
      end
      --  
    end
    --
    if love.mouse.isDown(1) then
      if (monCursor == true and monPlace == true and monBool == true) then 
        monCursor = false 
        placeManager.decorsToPlace.decors = decorsmanager.CreerDecors(placeManager.decorsToPlace.type, placeManager.decorsToPlace.forme, xReel, yReel, placeManager.decorsToPlace.taille)
      end
      --
    end
    --   
  end
  --
end
--

placeManager.draw = function ()
    if phase == "placerDecors" then
      -----  Dessine le fond gris, le texte et la case numerique
      love.graphics.setColor(colorLightGrey)
      love.graphics.rectangle("fill", camera.CalcX(100), camera.CalcY(100), (200*camera.scaleX), (400*camera.scaleY))
      love.graphics.setColor(colorBlack)
      love.graphics.setFont(infoFont)
      love.graphics.print("Selectionner decors", camera.CalcX(130), camera.CalcY(105), 0, camera.scaleX, camera.scaleY)
      love.graphics.print("Type de decors :", camera.CalcX(105), camera.CalcY(125), 0, camera.scaleX, camera.scaleY)
      love.graphics.print("Forme du decors :", camera.CalcX(105), camera.CalcY(190), 0, camera.scaleX, camera.scaleY)
      love.graphics.print("monCursor :"..tostring(monCursor).." monBool :"..tostring(monBool).." monPlace :"..tostring(monPlace), camera.CalcX(105), camera.CalcY(340), 0, camera.scaleX, camera.scaleY)
      love.graphics.print("Taille du decors :", camera.CalcX(105), camera.CalcY(360), 0, camera.scaleX, camera.scaleY)
      love.graphics.rectangle("line", camera.CalcX(170), camera.CalcY(380), camera.scaleX * (60), camera.scaleY * (30))
      love.graphics.printf(placeManager.decorsToPlace.taille, camera.CalcX(100), camera.CalcY(386), 200, "center", 0, camera.scaleX, camera.scaleY)
--love.graphics.print("monChoix :"..placeManager.decorsToPlace.forme.."   "..placeManager.decorsToPlace.type.."   "..placeManager.decorsToPlace.taille, camera.CalcX(105), camera.CalcY(445), 0, camera.scaleX, camera.scaleY)
      ------ Si survole un bouton "type" alors mets une ombre dessous
      if (placeManager.monBouton ~= nil and placeManager.monBouton[5] == "bt_type") then
          love.graphics.setColor(colorBlack)
          love.graphics.rectangle("fill", camera.CalcX(placeManager.monBouton[1] + 5), camera.CalcY(placeManager.monBouton[3] + 5),camera.scaleX * placeManager.monBouton[2], camera.scaleY * placeManager.monBouton[4]) 
      end
      --
      ------ Fais le tour des boutons pour les afficher
      local n
      for n = 1, #liste_boutons, 1 do
        boutonAffiche = liste_boutons[n]
        ------------  Boutons "Type"
        if boutonAffiche[5] == "bt_type"  then
          love.graphics.setColor(boutonAffiche[6][2])
          love.graphics.rectangle("fill", camera.CalcX(boutonAffiche[1]), camera.CalcY(boutonAffiche[3]), camera.scaleX * boutonAffiche[2], camera.scaleY * boutonAffiche[4])
          love.graphics.setColor(colorBlack)
          love.graphics.print(boutonAffiche[6][1], camera.CalcX(boutonAffiche[1] +5), camera.CalcY(boutonAffiche[3] +2), 0, camera.scaleX, camera.scaleY)
          love.graphics.setColor(colorWhite)
          ----------  Surlignage du Bouton TYPE selectionné
          if boutonAffiche[6][1] == placeManager.decorsToPlace.type then
          love.graphics.setColor(colorWhite)           
          love.graphics.rectangle("line", camera.CalcX(boutonAffiche[1]), camera.CalcY(boutonAffiche[3]), camera.scaleX * boutonAffiche[2], camera.scaleY * boutonAffiche[4])
          love.graphics.setColor(colorYellow)           
          love.graphics.rectangle("line", camera.CalcX(boutonAffiche[1]), camera.CalcY(boutonAffiche[3]), camera.scaleX * boutonAffiche[2], camera.scaleY * boutonAffiche[4])          
          love.graphics.setColor(colorBlack)           
          love.graphics.rectangle("line", camera.CalcX(boutonAffiche[1]-1), camera.CalcY(boutonAffiche[3]-1), camera.scaleX * (2 + boutonAffiche[2]), camera.scaleY * ( 2+ boutonAffiche[4]))
          love.graphics.setColor(colorWhite)
          end
        --        
        ----------   Affiche les images corresponadant aux Boutons FORME et FLECHES
        elseif (boutonAffiche[5] == "bt_forme" or boutonAffiche[5] == "bt_fleche" ) then
          love.graphics.setColor(colorWhite)
          love.graphics.draw(boutonAffiche[6][2],camera.CalcX(boutonAffiche[1]), camera.CalcY(boutonAffiche[3]), 0, camera.scaleX, camera.scaleY)
        ----------  Affiche le bouton de VALIDATION
        elseif boutonAffiche[5] == "bt_ok" then
          love.graphics.setColor(colorWhite)
          love.graphics.draw(boutonAffiche[6][2], camera.CalcX(boutonAffiche[1] -5), camera.CalcY(boutonAffiche[3] -3), 0, camera.scaleX *1.1, camera.scaleY * 1.1)
          love.graphics.setColor(colorBlack)
          love.graphics.printf(boutonAffiche[6][3], camera.CalcX(160), camera.CalcY(435), 75, "center",0, camera.scaleX, camera.scaleY)
        end
        --
      end
      -----------  Affiche image_hovered si Boutons FORME et FLECHE survoles par souris
      if placeManager.monBouton ~= nil and (placeManager.monBouton[5] == "bt_forme" or placeManager.monBouton[5] == "bt_fleche" ) then
          love.graphics.setColor(colorLightGrey)
          love.graphics.rectangle("fill", camera.CalcX(placeManager.monBouton[1]), camera.CalcY(placeManager.monBouton[3]), camera.scaleX * placeManager.monBouton[2], camera.scaleY * placeManager.monBouton[4])        
          love.graphics.setColor(colorWhite)
          love.graphics.draw(placeManager.monBouton[6][3],camera.CalcX(placeManager.monBouton[1]), camera.CalcY(placeManager.monBouton[3]), 0, camera.scaleX, camera.scaleY)        
      end
      --
      ------------- Affiche image_selected si Boutons Formes selectionnes
      local n 
      for n = 1 , # liste_boutons, 1 do 
        b = liste_boutons[n]
        if b[5] == "bt_forme" then 
          if b[6][1] == placeManager.decorsToPlace.forme then
          love.graphics.setColor(colorLightGrey)
          love.graphics.rectangle("fill", camera.CalcX(b[1]), camera.CalcY(b[3]), camera.scaleX * b[2], camera.scaleY * b[4])        
          love.graphics.setColor(colorWhite)
          love.graphics.draw(b[6][4],camera.CalcX(b[1]), camera.CalcY(b[3]), 0, camera.scaleX, camera.scaleY)            
          end
          --          
        end
        --
      end
      --
      if monCursor == true then
        love.graphics.setColor(placeManager.decorsToPlace.color)
        love.graphics.polygon("fill", placeManager.decorsToPlace.liste_points)
        love.graphics.setColor(colorWhite)
      end
      
    end
end
--
return placeManager