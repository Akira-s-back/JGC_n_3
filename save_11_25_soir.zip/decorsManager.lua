local camera = require("cameraManager")
--local placeManager = require ("placeManager")

------------ TO DO : Etoiles et lettres en 2 polygones, pb de "convexite"

local decorsManager = {}
decorsManager.liste_decors = {}
liste_horizontal = {0,0,4,0,4,1,0,1}
liste_vertical   = {0,0,1,0,1,4,0,4}
liste_slopeNeg   = {0,1,1,0,4,3,3,4}
liste_slopePos   = {0,3,3,0,4,1,1,4}
liste_LettreL = {0,0, 2,0, 2,1, 1,1, 1,3, 0,3}
liste_slopeNeg2   = {0,0,2,0,3,2,2,2,2,1,0,1,0,2,-1,2}

----------- Fonction créeant une table de points {x1,y1,x2,y2...xn,yn} correspondant 
-- aux coordonnées des n sommets du polycgone, placé en (decors.x, decors.y) à une eclle de decors.scale pixels
decorsManager.CalcSommets = function(pShape, pX, pY,pScale)
 local listePoints = {}
 
 if pShape == "Horiz"    then liste_shape = liste_horizontal end
 if pShape == "vert."      then liste_shape = liste_vertical   end
 if pShape == "Pente_Pos" then liste_shape = liste_slopePos   end
 if pShape == "Pente_Neg" then liste_shape = liste_slopeNeg   end
 if pShape == "Lettre_L"       then liste_shape = liste_LettreL    end
 
 for n = 1, #liste_shape, 1 do
  local res = liste_shape[n]
  if n%2 == 0 then -----si n est pair ON TRAITE LES Y des sommets du polygone
    res = pY + (res * pScale)
  elseif n%2 ==1 then ------------si n est impair, ON TRAITE LES X des sommets du polygone
    res = pX + (res * pScale)
  end
  table.insert(listePoints, res)  
end
--
 return listePoints
end
--


decorsManager.CreerDecors = function (pType, pShape, pX, pY, pScale)
local decors = {}
local liste_shape = {}
local n

decors.type = pType
if decors.type == "Haut"     then decors.color= colorBlue end
if decors.type == "Bas"      then decors.color= colorGreen end
if decors.type == "Infranch" then decors.color= colorRed end

decors.shape = pShape
decors.x = pX
decors.y = pY
decors.scale = pScale
decors.points= {}
decors.points = decorsManager.CalcSommets(decors.shape, decors.x, decors.y, decors.scale)
--

table.insert(decorsManager.liste_decors, decors)

return decors

end
--


decorsManager.draw = function()
  local n
  for n=1, #decorsManager.liste_decors, 1 do 
    local decors = decorsManager.liste_decors[n]
    love.graphics.setColor(decors.color)
    love.graphics.polygon("fill", decors.points)
    love.graphics.setColor(255,255,255)
  end
  --

end
--
decorsManager.update = function(dt)
  

end
--


return decorsManager