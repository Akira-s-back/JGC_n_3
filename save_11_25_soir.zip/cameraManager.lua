local camera = {}

camera.x = 0
camera.y = 0
camera.scaleX = 1
camera.scaleY = 1
camera.rotation = 0
camera.vitesse = 120

camera.Set = function()
  love.graphics.push()
  love.graphics.rotate(camera.rotation)
  love.graphics.scale(1/camera.scaleX, 1/camera.scaleY)
  love.graphics.translate(camera.x, camera.y)
end
--
camera.Unset = function()
  love.graphics.pop()
end
--
camera.MoveCam = function (pDx, pDy)
  camera.x = camera.x + pDx
  camera.y = camera.y + pDy
end
--
camera.RotateCam = function (pRot)
  camera.rotation = camera.rotation + pRot
end
--
camera.ScaleCam = function (pScX, pScY)
  camera.scaleX = camera.scaleX * pScX
  camera.scaleY = camera.scaleY * pScY
end
--
camera.SetScale = function (pScX, pScY)
  camera.scaleX = pScX
  camera.scaleY = pScY
end
--
camera.SetPosition = function(pX, pY)
  camera.x = pX
  camera.y = pY
end
--
------Renvoie une valeur valX/Y correspondant à pX/Y dans le Terrain initial (echelle 1, aucun translate)
camera.CalcX = function (pX)
  return ((pX * camera.scaleX) - camera.x)
end
--
camera.CalcY = function (pY)
  return ((pY * camera.scaleY) - camera.y)
end
--


return camera
